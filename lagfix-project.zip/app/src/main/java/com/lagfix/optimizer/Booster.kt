package com.lagfix.optimizer

import android.app.ActivityManager
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import kotlin.concurrent.thread

object Booster {

    // App nhắn tin / nhạc: không tắt để khỏi mất thông báo
    private val keepApps = listOf(
        "com.zing.zalo",
        "com.facebook.orca",
        "org.telegram.messenger",
        "com.whatsapp",
        "com.viber.voip",
        "com.spotify.music",
        "com.google.android.apps.messaging"
    )

    fun availMem(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem
    }

    private fun protectedPackages(ctx: Context): Set<String> {
        val set = HashSet<String>()
        set.add(ctx.packageName)
        set.addAll(keepApps)
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val home = ctx.packageManager.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
            home?.activityInfo?.packageName?.let { set.add(it) }

            val ime = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            if (ime != null) set.add(ime.substringBefore('/'))

            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            tm?.defaultDialerPackage?.let { set.add(it) }

            Telephony.Sms.getDefaultSmsPackage(ctx)?.let { set.add(it) }
        } catch (e: Exception) {
            // bỏ qua, vẫn dọn với danh sách đã có
        }
        return set
    }

    // Trả về số byte RAM giải phóng được (ước lượng). Gọi trong luồng nền.
    fun clean(ctx: Context): Long {
        val before = availMem(ctx)
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val keep = protectedPackages(ctx)
        try {
            for (a in ctx.packageManager.getInstalledApplications(0)) {
                if (a.packageName in keep) continue
                if ((a.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
                am.killBackgroundProcesses(a.packageName)
            }
        } catch (e: Exception) {
            // bỏ qua
        }
        Thread.sleep(800)
        val after = availMem(ctx)
        return if (after > before) after - before else 0L
    }
}

class RamJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        thread {
            Booster.clean(applicationContext)
            jobFinished(params, false)
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = false
}
