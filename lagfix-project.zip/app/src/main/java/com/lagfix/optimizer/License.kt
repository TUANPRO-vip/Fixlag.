package com.lagfix.optimizer

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

object License {
    // File danh sách key (chỉ chứa mã băm SHA-256, không chứa key gốc)
    private const val KEY_URL = "https://raw.githubusercontent.com/TUANPRO-vip/Fixlag./main/keys.json"

    // Mất mạng tối đa 7 ngày vẫn dùng được, sau đó phải kết nối mạng để xác minh lại
    private const val GRACE_MS = 7L * 24 * 60 * 60 * 1000

    enum class Result { OK, INVALID, EXPIRED, NETWORK }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("license", Context.MODE_PRIVATE)

    fun normalize(s: String): String {
        val n = s.uppercase().filter { it.isLetterOrDigit() }
        return if (n.startsWith("TSX")) n else "TSX$n"
    }

    private fun sha256(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    private fun fetch(): JSONObject? {
        return try {
            val c = URL(KEY_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.useCaches = false
            try {
                if (c.responseCode != 200) {
                    null
                } else {
                    JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    // Trả về hạn dùng ("lifetime" hoặc yyyy-MM-dd) nếu key có trong danh sách, ngược lại null
    private fun find(json: JSONObject, hash: String): String? {
        val arr = json.optJSONArray("keys") ?: return null
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("h").equals(hash, ignoreCase = true)) {
                return o.optString("exp", "lifetime")
            }
        }
        return null
    }

    private fun expired(exp: String): Boolean {
        if (exp.isBlank() || exp.equals("lifetime", ignoreCase = true)) return false
        return try {
            val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val end = f.parse(exp) ?: return false
            System.currentTimeMillis() > end.time + 24L * 60 * 60 * 1000
        } catch (e: Exception) {
            false
        }
    }

    // Gọi trong luồng nền
    fun activate(ctx: Context, rawKey: String): Result {
        val hash = sha256(normalize(rawKey))
        val json = fetch() ?: return Result.NETWORK
        val exp = find(json, hash) ?: return Result.INVALID
        if (expired(exp)) return Result.EXPIRED
        prefs(ctx).edit()
            .putString("h", hash)
            .putString("exp", exp)
            .putLong("ok", System.currentTimeMillis())
            .apply()
        return Result.OK
    }

    fun isActive(ctx: Context): Boolean {
        val p = prefs(ctx)
        if (p.getString("h", null) == null) return false
        if (expired(p.getString("exp", "") ?: "")) return false
        return System.currentTimeMillis() - p.getLong("ok", 0L) < GRACE_MS
    }

    // Gọi trong luồng nền. Trả false nếu key đã bị thu hồi hoặc hết hạn.
    fun recheck(ctx: Context): Boolean {
        val p = prefs(ctx)
        val hash = p.getString("h", null) ?: return false
        val json = fetch() ?: return true
        val exp = find(json, hash)
        if (exp == null || expired(exp)) {
            p.edit().clear().apply()
            return false
        }
        p.edit().putString("exp", exp).putLong("ok", System.currentTimeMillis()).apply()
        return true
    }

    fun status(ctx: Context): String {
        val exp = prefs(ctx).getString("exp", "") ?: ""
        return if (exp.isBlank() || exp.equals("lifetime", ignoreCase = true)) {
            "Key: vĩnh viễn"
        } else {
            "Key: dùng đến $exp"
        }
    }
}
