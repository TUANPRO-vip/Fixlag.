package com.lagfix.optimizer

import android.app.job.JobParameters
import android.app.job.JobService
import android.os.Environment
import java.io.File
import kotlin.concurrent.thread

object Junk {
    private val junkExt = setOf("tmp", "temp", "log", "crdownload", "part")

    fun scan(includeApk: Boolean): List<File> {
        val found = ArrayList<File>()
        Environment.getExternalStorageDirectory().walkTopDown()
            .onEnter { it.name != "Android" }
            .forEach { f ->
                if (f.isFile) {
                    val n = f.name.lowercase()
                    val e = f.extension.lowercase()
                    if (e in junkExt ||
                        (includeApk && e == "apk") ||
                        n.contains("thumbdata") ||
                        f.parentFile?.name == ".thumbnails"
                    ) {
                        found.add(f)
                    }
                }
            }
        return found
    }

    fun size(list: List<File>): Long {
        var total = 0L
        for (f in list) total += f.length()
        return total
    }

    // Trả về (số file đã xóa, số byte giải phóng)
    fun delete(list: List<File>): Pair<Int, Long> {
        var freed = 0L
        var count = 0
        for (f in list) {
            val s = f.length()
            if (f.delete()) {
                freed += s
                count++
            }
        }
        return Pair(count, freed)
    }
}

class JunkJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        thread {
            if (Environment.isExternalStorageManager()) {
                Junk.delete(Junk.scan(false))
            }
            jobFinished(params, false)
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = false
}
