package com.lagfix.optimizer

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread

private val C_BG = Color.parseColor("#0B1220")
private val C_CARD = Color.parseColor("#131C2E")
private val C_BTN = Color.parseColor("#1E293B")
private val C_CYAN = Color.parseColor("#22D3EE")
private val C_GREEN = Color.parseColor("#34D399")
private val C_MUTED = Color.parseColor("#94A3B8")

class MainActivity : Activity() {

    private lateinit var gauge: GaugeView
    private lateinit var ramLine: TextView
    private lateinit var ramResult: TextView
    private lateinit var boostBtn: Button
    private lateinit var statStorage: TextView
    private lateinit var statBattery: TextView
    private lateinit var statThermal: TextView
    private lateinit var junkText: TextView
    private lateinit var deleteBtn: Button

    private var junk: List<File> = emptyList()

    private class Toggle(val sw: Switch, val state: () -> Boolean)

    private val toggles = ArrayList<Toggle>()
    private var updating = false

    companion object {
        const val JOB_ID = 1001
        const val JOB_JUNK_ID = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(28))

        root.addView(label("LagFix", 28f, true, Color.WHITE))
        val sub = label("Tăng tốc  •  Làm mượt  •  Dọn dẹp", 13f, false, C_MUTED)
        sub.setPadding(0, 0, 0, dp(16))
        root.addView(sub)

        // ---- Thẻ RAM ----
        val ramCard = root.addCard()
        ramCard.gravity = Gravity.CENTER_HORIZONTAL
        gauge = GaugeView(this)
        ramCard.addView(gauge, LinearLayout.LayoutParams(dp(210), dp(210)))
        ramLine = label("", 14f, false, C_MUTED)
        ramCard.addView(ramLine)
        boostBtn = ramCard.addPrimaryButton("TĂNG TỐC RAM") { boostRam() }
        ramResult = label("", 13f, false, C_GREEN)
        ramResult.setPadding(0, dp(8), 0, 0)
        ramCard.addView(ramResult)

        // ---- Thông số nhanh ----
        val statRow = LinearLayout(this)
        statRow.orientation = LinearLayout.HORIZONTAL
        statStorage = statCell(statRow, "Bộ nhớ trống")
        statBattery = statCell(statRow, "Pin")
        statThermal = statCell(statRow, "Nhiệt độ")
        val statLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        statLp.setMargins(0, 0, 0, dp(12))
        root.addView(statRow, statLp)

        // ---- Chức năng (bật / tắt) ----
        root.addView(section("CHỨC NĂNG"))
        addToggle(
            root, "Chế độ chơi game",
            "Dọn RAM, bật không làm phiền, tắt đồng bộ nền, giảm hiệu ứng",
            { prefs().getBoolean("game", false) }
        ) { on -> setGame(on) }
        addToggle(
            root, "Tăng tốc RAM tự động",
            "Tự dọn RAM nền mỗi 15 phút",
            { isJobScheduled(JOB_ID) }
        ) { on -> toggleRamJob(on) }
        addToggle(
            root, "Dọn sâu RAM",
            "Khi dọn RAM, tắt thêm YouTube, Chrome, Maps, Ảnh... đang chạy nền",
            { prefs().getBoolean("deep", false) }
        ) { on -> prefs().edit().putBoolean("deep", on).apply() }
        addToggle(
            root, "Làm mượt máy",
            "Giảm hiệu ứng chuyển cảnh xuống 0.5x, thao tác nhanh hơn",
            { isSmooth() }
        ) { on -> if (!setSmooth(on)) showSecureDialog() }
        addToggle(
            root, "Giảm độ sáng màn hình",
            "Hạ sáng còn khoảng 35%, bớt nóng và đỡ tốn pin",
            { prefs().getBoolean("dim", false) }
        ) { on -> toggleDim(on) }
        addToggle(
            root, "Tắt đồng bộ nền",
            "Bớt app tự đồng bộ ngầm, giảm nóng máy",
            { isSyncOff() }
        ) { on -> toggleSync(on) }
        addToggle(
            root, "Không làm phiền",
            "Chặn thông báo làm gián đoạn khi chơi game",
            { isDnd() }
        ) { on -> toggleDnd(on) }
        addToggle(
            root, "Tắt rung phản hồi",
            "Tắt rung khi chạm, đỡ tốn pin",
            { isSettingOff(Settings.System.HAPTIC_FEEDBACK_ENABLED) }
        ) { on -> setSystemFlag(Settings.System.HAPTIC_FEEDBACK_ENABLED, !on) }
        addToggle(
            root, "Tắt âm thanh chạm",
            "Tắt tiếng bấm khi chạm màn hình",
            { isSettingOff(Settings.System.SOUND_EFFECTS_ENABLED) }
        ) { on -> setSystemFlag(Settings.System.SOUND_EFFECTS_ENABLED, !on) }
        addToggle(
            root, "Tự dọn file rác mỗi ngày",
            "Tự xóa file tạm, log, ảnh thu nhỏ mỗi 24 giờ",
            { isJobScheduled(JOB_JUNK_ID) }
        ) { on -> toggleJunkJob(on) }
        addToggle(
            root, "Quét cả file APK",
            "Khi quét file rác, tìm thêm file .apk đã tải (không tự xóa)",
            { prefs().getBoolean("junk_apk", false) }
        ) { on -> prefs().edit().putBoolean("junk_apk", on).apply() }

        // ---- Dọn file rác ----
        root.addView(section("DỌN DẸP"))
        val junkCard = root.addCard()
        junkCard.addView(label("Dọn file rác", 16f, true, Color.WHITE))
        junkText = label("Chưa quét.", 13f, false, C_MUTED)
        junkText.setPadding(0, dp(4), 0, 0)
        junkCard.addView(junkText)
        junkCard.addSecondaryButton("Quét file rác") { startScan() }
        deleteBtn = junkCard.addSecondaryButton("Xóa file rác đã tìm thấy") { confirmDelete() }
        deleteBtn.visibility = View.GONE

        val foot = label("LagFix v0.4", 11f, false, C_MUTED)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, dp(8), 0, 0)
        root.addView(foot, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C_BG)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        syncToggles()
    }

    // ------------------------------------------------------------------
    // Thông số
    // ------------------------------------------------------------------
    private fun refresh() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedPct = (100 - (mi.availMem * 100 / mi.totalMem)).toInt()
        gauge.update(usedPct, "$usedPct%", "RAM đang dùng")
        ramLine.text = "Còn trống ${fmt(mi.availMem)} / ${fmt(mi.totalMem)}"

        val stat = StatFs(Environment.getDataDirectory().path)
        statStorage.text = fmt(stat.availableBytes)

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        statBattery.text = "${level * 100 / scale}% · ${String.format("%.1f", temp)}°C"

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        statThermal.text = when (pm.currentThermalStatus) {
            0 -> "Bình thường"
            1 -> "Hơi ấm"
            2 -> "Nóng vừa"
            3 -> "Nóng nhiều"
            else -> "Rất nóng"
        }
    }

    private fun boostRam() {
        boostBtn.isEnabled = false
        boostBtn.alpha = 0.6f
        boostBtn.text = "Đang tăng tốc..."
        ramResult.text = ""
        thread {
            val freed = Booster.clean(this)
            runOnUiThread {
                boostBtn.isEnabled = true
                boostBtn.alpha = 1f
                boostBtn.text = "TĂNG TỐC RAM"
                ramResult.text = if (freed >= 20L * 1048576L) {
                    "Đã giải phóng ${fmt(freed)}"
                } else {
                    "RAM đã ở mức tối ưu"
                }
                refresh()
            }
        }
    }

    // ------------------------------------------------------------------
    // Công tắc chức năng
    // ------------------------------------------------------------------
    private fun prefs() = getSharedPreferences("lagfix", MODE_PRIVATE)

    private fun syncToggles() {
        updating = true
        for (t in toggles) t.sw.isChecked = t.state()
        updating = false
    }

    private fun nm(): NotificationManager = getSystemService(NotificationManager::class.java)
    private fun js(): JobScheduler = getSystemService(JobScheduler::class.java)

    // Không làm phiền
    private fun dndGranted(): Boolean = nm().isNotificationPolicyAccessGranted
    private fun isDnd(): Boolean = nm().currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
    private fun setDnd(on: Boolean) {
        nm().setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    private fun toggleDnd(on: Boolean) {
        if (!dndGranted()) {
            toast("Hãy cấp quyền Không làm phiền cho LagFix rồi bật lại")
            openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        setDnd(on)
    }

    // Đồng bộ nền
    private fun isSyncOff(): Boolean = !ContentResolver.getMasterSyncAutomatically()
    private fun trySync(off: Boolean): Boolean {
        return try {
            ContentResolver.setMasterSyncAutomatically(!off)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    private fun toggleSync(on: Boolean) {
        if (!trySync(on)) toast("Thiếu quyền đồng bộ")
    }

    // Làm mượt (animation scale)
    private fun isSmooth(): Boolean =
        Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) < 1f

    private fun setSmooth(on: Boolean): Boolean {
        return try {
            val v = if (on) 0.5f else 1f
            Settings.Global.putFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, v)
            Settings.Global.putFloat(contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, v)
            Settings.Global.putFloat(contentResolver, Settings.Global.WINDOW_ANIMATION_SCALE, v)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    private fun showSecureDialog() {
        AlertDialog.Builder(this)
            .setTitle("Cần cấp quyền")
            .setMessage(
                "Làm mượt máy cần quyền WRITE_SECURE_SETTINGS (cấp một lần qua Shizuku hoặc ADB).\n\n" +
                    "Tạm thời bạn có thể chỉnh tay: Tùy chọn nhà phát triển > đặt 3 mục Tỷ lệ hoạt ảnh về 0.5x."
            )
            .setPositiveButton("Mở tùy chọn nhà phát triển") { _, _ ->
                openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    // Tự dọn RAM / file rác định kỳ
    private fun isJobScheduled(id: Int): Boolean = js().getPendingJob(id) != null

    private fun toggleRamJob(on: Boolean) {
        if (on) {
            val info = JobInfo.Builder(JOB_ID, ComponentName(this, RamJobService::class.java))
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js().schedule(info)
            toast("Sẽ tự dọn RAM mỗi 15 phút")
        } else {
            js().cancel(JOB_ID)
        }
    }

    private fun toggleJunkJob(on: Boolean) {
        if (on) {
            if (!Environment.isExternalStorageManager()) {
                toast("Bật 'Cho phép quản lý mọi tệp' cho LagFix rồi bật lại")
                openSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                return
            }
            val info = JobInfo.Builder(JOB_JUNK_ID, ComponentName(this, JunkJobService::class.java))
                .setPeriodic(24 * 60 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js().schedule(info)
            toast("Sẽ tự dọn file rác mỗi ngày")
        } else {
            js().cancel(JOB_JUNK_ID)
        }
    }

    // Quyền sửa cài đặt hệ thống (độ sáng, rung, âm thanh chạm)
    private fun ensureWriteSettings(): Boolean {
        if (Settings.System.canWrite(this)) return true
        toast("Hãy cho phép LagFix sửa cài đặt hệ thống rồi bật lại")
        openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
        return false
    }

    private fun isSettingOff(key: String): Boolean = Settings.System.getInt(contentResolver, key, 1) == 0

    private fun setSystemFlag(key: String, enabled: Boolean) {
        if (!ensureWriteSettings()) return
        try {
            Settings.System.putInt(contentResolver, key, if (enabled) 1 else 0)
        } catch (e: Exception) {
            toast("Máy không cho đổi mục này")
        }
    }

    private fun toggleDim(on: Boolean) {
        if (!ensureWriteSettings()) return
        val cr = contentResolver
        val p = prefs()
        try {
            if (on) {
                val mode = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                val level = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
                p.edit().putInt("dim_mode", mode).putInt("dim_level", level).putBoolean("dim", true).apply()
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 90)
            } else {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, p.getInt("dim_level", 128))
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, p.getInt("dim_mode", 0))
                p.edit().putBoolean("dim", false).apply()
            }
        } catch (e: Exception) {
            toast("Máy không cho đổi độ sáng")
            p.edit().putBoolean("dim", false).apply()
        }
    }

    // Chế độ chơi game = gộp các chức năng trên
    private fun setGame(on: Boolean) {
        val p = prefs()
        if (on) {
            val changed = HashSet<String>()
            if (!isDnd() && dndGranted()) {
                setDnd(true)
                changed.add("dnd")
            }
            if (!isSyncOff() && trySync(true)) changed.add("sync")
            if (!isSmooth() && setSmooth(true)) changed.add("anim")
            p.edit().putBoolean("game", true).putStringSet("game_changed", changed).apply()
            boostRam()
            toast(if (changed.size < 3) "Đã bật chế độ chơi game (một số mục cần cấp quyền)" else "Đã bật chế độ chơi game")
        } else {
            val changed = p.getStringSet("game_changed", emptySet()) ?: emptySet()
            if ("dnd" in changed && dndGranted()) setDnd(false)
            if ("sync" in changed) trySync(false)
            if ("anim" in changed) setSmooth(false)
            p.edit().putBoolean("game", false).apply()
            toast("Đã tắt chế độ chơi game")
        }
    }

    // ------------------------------------------------------------------
    // Dọn file rác
    // ------------------------------------------------------------------
    private fun startScan() {
        if (!Environment.isExternalStorageManager()) {
            toast("Bật 'Cho phép quản lý mọi tệp' cho LagFix rồi quay lại bấm quét")
            openSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            return
        }
        junkText.text = "Đang quét..."
        deleteBtn.visibility = View.GONE
        val withApk = prefs().getBoolean("junk_apk", false)
        thread {
            val found = Junk.scan(withApk)
            val total = Junk.size(found)
            runOnUiThread {
                junk = found
                if (found.isEmpty()) {
                    junkText.text = "Không có file rác."
                } else {
                    junkText.text = "Tìm thấy ${found.size} file, khoảng ${fmt(total)}."
                    deleteBtn.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun confirmDelete() {
        val total = Junk.size(junk)
        AlertDialog.Builder(this)
            .setTitle("Xóa file rác?")
            .setMessage("Xóa ${junk.size} file (khoảng ${fmt(total)}). Không thể hoàn tác.")
            .setPositiveButton("Xóa") { _, _ -> deleteJunk() }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun deleteJunk() {
        val list = junk
        thread {
            val res = Junk.delete(list)
            runOnUiThread {
                junk = emptyList()
                junkText.text = "Đã xóa ${res.first} file, giải phóng ${fmt(res.second)}."
                deleteBtn.visibility = View.GONE
                refresh()
            }
        }
    }

    // ------------------------------------------------------------------
    // Tiện ích giao diện
    // ------------------------------------------------------------------
    private fun openSettings(action: String, uri: Uri? = null) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = uri
            startActivity(i)
        } catch (e: Exception) {
            toast("Máy không mở được màn hình này")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundRect(col: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(col)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun label(text: String, size: Float, bold: Boolean, col: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(col)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun section(text: String): TextView {
        val t = label(text, 12.5f, true, C_CYAN)
        t.setPadding(dp(4), dp(8), 0, dp(8))
        return t
    }

    private fun statCell(parent: LinearLayout, title: String): TextView {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundRect(C_CARD, 14)
        c.setPadding(dp(12), dp(12), dp(12), dp(12))
        c.addView(label(title, 11.5f, false, C_MUTED))
        val v = label("-", 14f, true, Color.WHITE)
        c.addView(v)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        parent.addView(c, lp)
        return v
    }

    private fun LinearLayout.addCard(): LinearLayout {
        val c = LinearLayout(this@MainActivity)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundRect(C_CARD, 16)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        addView(c, lp)
        return c
    }

    private fun LinearLayout.addPrimaryButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this@MainActivity)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.parseColor("#06222B"))
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.textSize = 16f
        b.background = roundRect(C_CYAN, 28)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.setMargins(0, dp(14), 0, 0)
        addView(b, lp)
        return b
    }

    private fun LinearLayout.addSecondaryButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this@MainActivity)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = roundRect(C_BTN, 24)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        lp.setMargins(0, dp(10), 0, 0)
        addView(b, lp)
        return b
    }

    private fun addToggle(
        parent: LinearLayout,
        title: String,
        desc: String,
        state: () -> Boolean,
        apply: (Boolean) -> Unit
    ) {
        val row = parent.addCard()
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(label(title, 16f, true, Color.WHITE))
        val d = label(desc, 12.5f, false, C_MUTED)
        d.setPadding(0, dp(2), dp(8), 0)
        texts.addView(d)
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val sw = Switch(this)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(C_CYAN, Color.parseColor("#334155")))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#94A3B8")))
        sw.setOnCheckedChangeListener { _, checked ->
            if (!updating) {
                apply(checked)
                syncToggles()
            }
        }
        row.addView(sw)
        toggles.add(Toggle(sw, state))
    }

    private fun fmt(bytes: Long): String = when {
        bytes >= 1073741824L -> String.format("%.2f GB", bytes / 1073741824.0)
        bytes >= 1048576L -> String.format("%.0f MB", bytes / 1048576.0)
        else -> String.format("%d KB", bytes / 1024)
    }
}
