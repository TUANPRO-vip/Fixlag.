package com.lagfix.optimizer

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var infoText: TextView
    private lateinit var junkText: TextView
    private lateinit var deleteBtn: Button
    private var junk: List<File> = emptyList()

    private val junkExt = setOf("tmp", "temp", "log", "crdownload", "part")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(24))
        }

        root.addView(label("LagFix", 26f, true))
        root.addView(label("Giám sát & dọn dẹp máy", 14f, false))

        infoText = label("", 16f, false).apply { setPadding(0, dp(16), 0, dp(8)) }
        root.addView(infoText)
        root.addButton("Làm mới thông số") { refresh() }

        root.addView(label("Dọn file rác", 18f, true).apply { setPadding(0, dp(24), 0, dp(4)) })
        junkText = label("Chưa quét.", 15f, false)
        root.addView(junkText)
        root.addButton("Quét file rác") { startScan() }
        deleteBtn = root.addButton("Xóa file rác đã tìm thấy") { confirmDelete() }
        deleteBtn.visibility = View.GONE

        root.addView(label("Lối tắt cài đặt", 18f, true).apply { setPadding(0, dp(24), 0, dp(4)) })
        root.addButton("Dung lượng lưu trữ hệ thống") { openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        root.addButton("Giới hạn pin / app chạy nền") { openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
        root.addButton("Không làm phiền (cấp quyền DND)") { openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
        root.addButton("Tùy chọn nhà phát triển (animation)") { openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
            isFillViewport = true
            addView(root)
        })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedPct = 100 - (mi.availMem * 100 / mi.totalMem)

        val stat = StatFs(Environment.getDataDirectory().path)

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = when (pm.currentThermalStatus) {
            0 -> "Bình thường"
            1 -> "Hơi ấm"
            2 -> "Nóng vừa"
            3 -> "Nóng nhiều (máy đang giảm hiệu năng)"
            else -> "Rất nóng"
        }

        infoText.text = "RAM: dùng $usedPct%  (còn ${fmt(mi.availMem)} / ${fmt(mi.totalMem)})\n" +
            "Bộ nhớ trống: ${fmt(stat.availableBytes)} / ${fmt(stat.totalBytes)}\n" +
            "Pin: ${level * 100 / scale}%  |  ${String.format("%.1f", temp)}°C\n" +
            "Nhiệt độ hệ thống: $thermal"
    }

    private fun startScan() {
        if (!Environment.isExternalStorageManager()) {
            toast("Bật 'Cho phép quản lý mọi tệp' cho LagFix rồi quay lại bấm quét")
            openSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            return
        }
        junkText.text = "Đang quét..."
        deleteBtn.visibility = View.GONE
        thread {
            val found = ArrayList<File>()
            Environment.getExternalStorageDirectory().walkTopDown()
                .onEnter { it.name != "Android" }
                .forEach { f ->
                    if (f.isFile) {
                        val n = f.name.lowercase()
                        if (f.extension.lowercase() in junkExt ||
                            n.contains("thumbdata") ||
                            f.parentFile?.name == ".thumbnails"
                        ) {
                            found.add(f)
                        }
                    }
                }
            var total = 0L
            for (f in found) total += f.length()
            runOnUiThread {
                junk = found
                if (found.isEmpty()) {
                    junkText.text = "Không có file rác."
                } else {
                    junkText.text = "Tìm thấy ${found.size} file, khoảng ${fmt(total)}."
                    deleteBtn.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun confirmDelete() {
        var total = 0L
        for (f in junk) total += f.length()
        AlertDialog.Builder(this)
            .setTitle("Xóa file rác?")
            .setMessage("Xóa ${junk.size} file (khoảng ${fmt(total)}). Không thể hoàn tác.")
            .setPositiveButton("Xóa") { _, _ -> deleteJunk() }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun deleteJunk() {
        val list = junk
        thread {
            var freed = 0L
            var count = 0
            for (f in list) {
                val size = f.length()
                if (f.delete()) {
                    freed += size
                    count++
                }
            }
            runOnUiThread {
                junk = emptyList()
                junkText.text = "Đã xóa $count file, giải phóng ${fmt(freed)}."
                deleteBtn.visibility = View.GONE
                refresh()
            }
        }
    }

    private fun openSettings(action: String, uri: Uri? = null) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = uri
            startActivity(i)
        } catch (e: Exception) {
            toast("Máy không mở được màn hình này")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun LinearLayout.addButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this@MainActivity)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        addView(b)
        return b
    }

    private fun fmt(bytes: Long): String = when {
        bytes >= 1073741824L -> String.format("%.2f GB", bytes / 1073741824.0)
        bytes >= 1048576L -> String.format("%.0f MB", bytes / 1048576.0)
        else -> String.format("%d KB", bytes / 1024)
    }
}
