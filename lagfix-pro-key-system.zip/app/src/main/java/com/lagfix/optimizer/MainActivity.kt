package com.lagfix.optimizer

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var infoText: TextView
    private lateinit var junkText: TextView
    private lateinit var deleteBtn: Button
    private var junk: List<File> = emptyList()

    // Replace with your deployed HTTPS server URL before building the APK.
    private val apiBase = "https://YOUR-SERVER-DOMAIN"
    private val prefs by lazy { getSharedPreferences("lagfix", Context.MODE_PRIVATE) }
    private val junkExt = setOf("tmp", "temp", "log", "crdownload", "part")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("key_valid", false)) refresh()
    }

    private fun showLogin() {
        val page = makeRoot()
        page.addView(label("LagFix Pro", 30f, true))
        page.addView(label("Đăng nhập bằng key được cấp bởi quản trị viên", 16f, false))
        val keyInput = EditText(this).apply {
            hint = "Nhập key"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }
        page.addView(keyInput)
        page.addButton("Xác thực key") {
            val key = keyInput.text.toString().trim()
            if (key.isBlank()) { toast("Hãy nhập key"); return@addButton }
            validateKey(key)
        }
        page.addView(label("Lưu ý: cần thay YOUR-SERVER-DOMAIN bằng địa chỉ máy chủ HTTPS của bạn.", 13f, false))
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
    }

    private fun validateKey(key: String) {
        if (apiBase.contains("YOUR-SERVER-DOMAIN")) {
            toast("Chưa cấu hình máy chủ key. Hãy sửa apiBase trong MainActivity.kt.")
            return
        }
        thread {
            var message = "Không kết nối được máy chủ key."
            var ok = false
            try {
                val conn = (URL("$apiBase/api/validate").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("key", key).toString().toByteArray(Charsets.UTF_8)) }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: "{}"
                val json = JSONObject(body)
                ok = conn.responseCode in 200..299 && json.optBoolean("valid", false)
                message = json.optString("message", if (ok) "Key hợp lệ" else "Key không hợp lệ hoặc đã hết hạn.")
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread {
                if (ok) {
                    prefs.edit().putBoolean("key_valid", true).putString("key", key).apply()
                    toast("Đăng nhập thành công")
                    showDashboard()
                } else toast(message)
            }
        }
    }

    private fun showDashboard() {
        val page = makeRoot()
        page.addView(label("LagFix Pro", 30f, true))
        page.addView(label("Công cụ theo dõi và tối ưu an toàn", 15f, false))
        infoText = label("", 16f, false).apply { setPadding(0, dp(16), 0, dp(8)) }
        page.addView(infoText)
        page.addButton("Làm mới thông số") { refresh() }

        page.addView(label("Tối ưu trước khi chơi", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        page.addButton("Mở cài đặt pin") { openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
        page.addButton("Mở tùy chọn nhà phát triển") { openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }
        page.addButton("Mở cài đặt lưu trữ") { openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        page.addButton("Kiểm tra nhanh rồi vào game") {
            refresh()
            AlertDialog.Builder(this)
                .setTitle("Chọn phiên bản Free Fire")
                .setItems(arrayOf("Free Fire thường", "Free Fire MAX")) { _, which ->
                    if (which == 0) launchGame("com.dts.freefireth") else launchGame("com.dts.freefiremax")
                }
                .setNegativeButton("Hủy", null)
                .show()
        }
        page.addButton("Khởi chạy Free Fire thường") { launchGame("com.dts.freefireth") }
        page.addButton("Khởi chạy Free Fire MAX") { launchGame("com.dts.freefiremax") }

        page.addView(label("Dọn file tạm", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        junkText = label("Chưa quét.", 15f, false)
        page.addView(junkText)
        page.addButton("Quét file tạm") { startScan() }
        deleteBtn = page.addButton("Xóa file đã chọn") { confirmDelete() }
        deleteBtn.visibility = View.GONE

        page.addButton("Đăng xuất key") {
            prefs.edit().remove("key_valid").remove("key").apply()
            showLogin()
        }
        page.addView(label("Giới hạn Android: ứng dụng không thể tự ép xung CPU/GPU, giải phóng RAM của ứng dụng khác hoặc bảo đảm tăng FPS nếu không có quyền hệ thống/root. Chỉ xóa file tạm có chọn lọc.", 13f, false).apply { setPadding(0, dp(18), 0, 0) })
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
            isFillViewport = true
            addView(page)
        })
        refresh()
    }

    private fun makeRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(36), dp(18), dp(24))
        setBackgroundColor(Color.parseColor("#0F172A"))
    }

    private fun refresh() {
        if (!::infoText.isInitialized) return
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val usedPct = 100 - (mi.availMem * 100 / mi.totalMem)
            val stat = StatFs(Environment.getDataDirectory().path)
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val thermal = when (pm.currentThermalStatus) {
                0 -> "Bình thường"; 1 -> "Hơi ấm"; 2 -> "Nóng vừa"
                3 -> "Nóng nhiều — hệ thống có thể giảm hiệu năng"; else -> "Rất nóng"
            }
            infoText.text = "RAM đang dùng: $usedPct% (còn ${fmt(mi.availMem)} / ${fmt(mi.totalMem)})\n" +
                "Bộ nhớ trống: ${fmt(stat.availableBytes)} / ${fmt(stat.totalBytes)}\n" +
                "Pin: ${if (level >= 0) level * 100 / scale else "?"}% | ${String.format("%.1f", temp)}°C\n" +
                "Nhiệt độ hệ thống: $thermal"
        } catch (_: Exception) { infoText.text = "Không đọc được một số thông số trên thiết bị này." }
    }

    private fun launchGame(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else {
            toast("Chưa cài game này. Mở Google Play để cài đặt.")
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))) }
        }
    }

    private fun startScan() {
        if (!Environment.isExternalStorageManager()) {
            toast("Cần cấp quyền quản lý tệp để quét thư mục chia sẻ.")
            openSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            return
        }
        junkText.text = "Đang quét..."
        deleteBtn.visibility = View.GONE
        thread {
            val found = ArrayList<File>()
            try {
                Environment.getExternalStorageDirectory().walkTopDown()
                    .onEnter { it.name != "Android" }
                    .forEach { f ->
                        if (f.isFile && (f.extension.lowercase() in junkExt ||
                            f.name.lowercase().contains("thumbdata") || f.parentFile?.name == ".thumbnails")) found.add(f)
                    }
            } catch (_: Exception) { }
            val total = found.sumOf { it.length() }
            runOnUiThread {
                junk = found
                junkText.text = if (found.isEmpty()) "Không tìm thấy file phù hợp." else "Tìm thấy ${found.size} file, khoảng ${fmt(total)}."
                deleteBtn.visibility = if (found.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun confirmDelete() {
        val total = junk.sumOf { it.length() }
        AlertDialog.Builder(this).setTitle("Xóa file đã quét?")
            .setMessage("Xóa ${junk.size} file (khoảng ${fmt(total)}). Chỉ tiếp tục nếu bạn chắc chắn.")
            .setPositiveButton("Xóa") { _, _ -> deleteJunk() }
            .setNegativeButton("Hủy", null).show()
    }

    private fun deleteJunk() {
        val list = junk
        thread {
            var freed = 0L; var count = 0
            for (f in list) { val size = f.length(); if (f.delete()) { freed += size; count++ } }
            runOnUiThread {
                junk = emptyList()
                junkText.text = "Đã xóa $count file, giải phóng ${fmt(freed)}."
                deleteBtn.visibility = View.GONE
                refresh()
            }
        }
    }

    private fun openSettings(action: String, uri: Uri? = null) {
        try { startActivity(Intent(action).apply { if (uri != null) data = uri }) }
        catch (_: Exception) { toast("Thiết bị không hỗ trợ màn hình cài đặt này.") }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun LinearLayout.addButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this@MainActivity).apply { this.text = text; isAllCaps = false; setOnClickListener { onClick() } }
        addView(b); return b
    }
    private fun fmt(bytes: Long): String = when {
        bytes >= 1073741824L -> String.format("%.2f GB", bytes / 1073741824.0)
        bytes >= 1048576L -> String.format("%.0f MB", bytes / 1048576.0)
        else -> String.format("%d KB", bytes / 1024)
    }
}
