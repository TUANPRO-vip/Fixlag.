# TSX PRO FIXLAG — Android starter v0.2.0

Giao diện HTML/CSS/JavaScript đóng gói thành APK bằng Capacitor. Có logo TSX PRO FIXLAG, hồ sơ game lưu cục bộ, thông tin thiết bị/màn hình, kiểm tra độ trễ tới điểm kiểm tra công khai, nút thử mở Free Fire, hướng dẫn ADB an toàn.

## Chạy trên máy tính

Yêu cầu Node.js 20+, Android Studio và Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Trong Android Studio, đợi Gradle Sync xong rồi chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Build APK bằng GitHub Actions

1. Tạo repository GitHub mới và tải toàn bộ nội dung thư mục này lên.
2. Mở tab **Actions**, bật workflow nếu GitHub yêu cầu.
3. Chọn **Build Android APK** → **Run workflow**.
4. Khi chạy xong, mở lần chạy đó và tải artifact `TSX-PRO-FIXLAG-debug-apk`.
5. Giải nén artifact để lấy `app-debug.apk`, rồi chuyển APK sang điện thoại và cài đặt. Có thể cần cho phép cài ứng dụng từ nguồn này.

Workflow tạo **debug APK để thử nghiệm**, chưa phải bản phát hành ký số cho Google Play. Không có APK được build sẵn trong ZIP này.

## Giới hạn quan trọng

- Trang web không tự đo chính xác CPU, FPS hệ thống hoặc nhiệt độ pin; các mục đó cần tích hợp Android native và quyền phù hợp.
- Đo mạng chỉ đo thời gian phản hồi tới điểm kiểm tra công khai, không phải ping trực tiếp tới máy chủ Free Fire.
- App không tự xóa cache/dữ liệu ứng dụng khác, không ép xung và không thay đổi độ nhạy trong game.
- ADB chỉ là hướng dẫn; JavaScript trong WebView không thực thi lệnh ADB trực tiếp.
