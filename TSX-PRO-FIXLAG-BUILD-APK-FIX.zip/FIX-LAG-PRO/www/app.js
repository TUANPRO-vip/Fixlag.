'use strict';
const $ = id => document.getElementById(id);
const STORAGE_KEY = 'tsxpro.fixlag.profile.v1';
function connection(){ return navigator.connection || navigator.mozConnection || navigator.webkitConnection || null; }
function updateDeviceInfo(){
  const ua = navigator.userAgent || 'Không có dữ liệu';
  let name = /Android/i.test(ua) ? 'Android' : 'Thiết bị khác';
  const match = ua.match(/Android\s([\d.]+)/i); if(match) name += ' ' + match[1];
  $('deviceType').textContent = name;
  $('screenInfo').textContent = `Màn hình ${screen.width}×${screen.height} • DPR ${window.devicePixelRatio || 1}`;
  const c = connection();
  $('networkType').textContent = c ? (c.type || c.effectiveType || 'Đã kết nối') : 'Không hỗ trợ API';
  $('networkInfo').textContent = c ? `Tiết kiệm dữ liệu: ${c.saveData ? 'bật' : 'tắt'}` : 'Android/WebView không cung cấp thông tin này';
  if(c && c.addEventListener) c.addEventListener('change', () => { $('networkType').textContent = c.type || c.effectiveType || 'Đã kết nối'; });
}
function loadProfile(){ const p = localStorage.getItem(STORAGE_KEY) || 'balanced'; $('profile').value = p; $('profileState').textContent = ({balanced:'Cân bằng',smooth:'Ưu tiên mượt',battery:'Tiết kiệm pin'})[p] || 'Mặc định'; }
$('scanBtn').addEventListener('click', () => { updateDeviceInfo(); loadProfile(); $('scanStatus').textContent = 'Đã đọc thông tin mà WebView cho phép. App không có quyền đo chính xác CPU, nhiệt độ hoặc FPS nếu chưa tích hợp mã Android gốc.'; });
$('saveProfile').addEventListener('click', () => { localStorage.setItem(STORAGE_KEY, $('profile').value); loadProfile(); $('profileMsg').textContent = 'Đã lưu hồ sơ trong FIX LAG PRO. Hồ sơ này chưa thay đổi cài đặt hệ thống hoặc game.'; });
$('pingBtn').addEventListener('click', async () => {
  const btn = $('pingBtn'); btn.disabled = true; $('pingMsg').textContent = 'Đang đo…';
  const samples = [];
  try {
    for(let i=0;i<3;i++){ const start = performance.now(); await fetch('https://www.google.com/generate_204?ts='+Date.now()+'_'+i,{mode:'no-cors',cache:'no-store'}); samples.push(Math.round(performance.now()-start)); }
    samples.sort((a,b)=>a-b); const ms = samples[1]; $('latency').textContent = ms+' ms'; $('latencyInfo').textContent = 'Thời gian phản hồi điểm kiểm tra'; $('pingMsg').textContent = `3 lần đo: ${samples.join(', ')} ms. Đây không phải ping máy chủ Free Fire.`;
  } catch(e){ $('latency').textContent = 'Lỗi'; $('latencyInfo').textContent = 'Không đo được'; $('pingMsg').textContent = 'Không thể kết nối điểm kiểm tra. Hãy kiểm tra mạng hoặc thử lại.'; }
  finally { btn.disabled = false; }
});
$('openGame').addEventListener('click', () => { $('profileMsg').textContent = 'Thử mở Free Fire… Nếu không chuyển ứng dụng, hãy mở game thủ công từ màn hình chính.'; window.location.href = 'intent://launch/#Intent;scheme=freefire;package=com.dts.freefireth;end'; });
$('resetBtn').addEventListener('click', () => { if(confirm('Xóa hồ sơ và tùy chọn lưu trong FIX LAG PRO? Không ảnh hưởng dữ liệu game.')) { localStorage.removeItem(STORAGE_KEY); loadProfile(); $('profileMsg').textContent = 'Đã xóa hồ sơ nội bộ của app.'; } });
$('adbInfo').addEventListener('click', () => { $('adbPanel').hidden = !$('adbPanel').hidden; });
$('version').textContent = 'v0.2.0'; updateDeviceInfo(); loadProfile();
