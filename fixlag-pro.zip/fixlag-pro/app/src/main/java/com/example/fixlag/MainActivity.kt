package com.example.fixlag

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showFragment(HomeFragment())
        highlightNav(R.id.navHome)

        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            showFragment(HomeFragment()); highlightNav(R.id.navHome)
        }
        findViewById<LinearLayout>(R.id.navGame).setOnClickListener {
            showFragment(GameFragment()); highlightNav(R.id.navGame)
        }
        findViewById<LinearLayout>(R.id.navTools).setOnClickListener {
            showFragment(ToolsFragment()); highlightNav(R.id.navTools)
        }
        findViewById<LinearLayout>(R.id.navAccount).setOnClickListener {
            showFragment(AccountFragment()); highlightNav(R.id.navAccount)
        }
    }

    private fun showFragment(f: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .commit()
    }

    private fun highlightNav(activeId: Int) {
        val ids = listOf(R.id.navHome, R.id.navGame, R.id.navTools, R.id.navAccount)
        ids.forEach { id ->
            val layout = findViewById<LinearLayout>(id)
            val tv = layout.getChildAt(1) as TextView
            tv.setTextColor(
                if (id == activeId) getColor(R.color.primary)
                else getColor(R.color.textDim)
            )
        }
    }
}
