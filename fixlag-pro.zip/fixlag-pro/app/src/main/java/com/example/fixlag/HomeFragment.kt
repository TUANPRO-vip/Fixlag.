package com.example.fixlag

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

    private lateinit var tvRamShort: TextView
    private lateinit var tvPingShort: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvRamShort = view.findViewById(R.id.tvRamShort)
        tvPingShort = view.findViewById(R.id.tvPingShort)
        refreshInfo()
    }

    private fun refreshInfo() {
        try {
            val am = requireContext().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val avail = mi.availMem / (1024 * 1024)
            val total = mi.totalMem / (1024 * 1024)
            tvRamShort.text = " RAM: ${avail} MB / ${total} MB"
        } catch (_: Exception) {}

        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.blockCountLong * stat.blockSizeLong / (1024 * 1024 * 1024)
            val free = stat.availableBlocksLong * stat.blockSizeLong / (1024 * 1024 * 1024)
            tvPingShort.text = " Bộ nhớ: ${free} GB / ${total} GB"
        } catch (_: Exception) {}
    }
}
