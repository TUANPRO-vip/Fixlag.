package com.example.fixlag

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class GameFragment : Fragment() {

    private data class Game(val icon: String, val name: String, val pub: String)

    private val games = listOf(
        Game("\uD83C\uDFAE", "Liên Quân Mobile", "Garena"),
        Game("\uD83D\uDD25", "Free Fire", "Garena"),
        Game("\uD83C\uDFAF", "PUBG Mobile", "Tencent"),
        Game("\u2728", "Genshin Impact", "HoYoverse"),
        Game("\uD83D\uDCA5", "Call of Duty Mobile", "Activision"),
        Game("\uD83E\uDDE9", "Roblox", "Roblox Corp"),
        Game("\u26CF\uFE0F", "Minecraft", "Mojang")
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_game, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val list = view.findViewById<LinearLayout>(R.id.listGames)
        val inflater = LayoutInflater.from(requireContext())
        games.forEach { g ->
            val item = inflater.inflate(R.layout.item_game, list, false)
            item.findViewById<TextView>(R.id.tvIcon).text = g.icon
            item.findViewById<TextView>(R.id.tvName).text = g.name
            item.findViewById<TextView>(R.id.tvPub).text = g.pub
            list.addView(item)
        }
    }
}
