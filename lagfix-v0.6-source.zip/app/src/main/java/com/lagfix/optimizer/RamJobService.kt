package com.lagfix.optimizer

import android.app.ActivityManager
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.content.pm.ApplicationInfo
import kotlin.concurrent.thread

/** Chay dinh ky (toi thieu moi 15 phut, do he dieu hanh gioi han) de dong cac app nen, giup giai phong RAM. */
class RamJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        thread {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                for (ai in packageManager.getInstalledApplications(0)) {
                    if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
                    if (ai.packageName == packageName) continue
                    am.killBackgroundProcesses(ai.packageName)
                }
            } catch (_: Exception) { }
            jobFinished(params, false)
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}
