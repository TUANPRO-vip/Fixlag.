const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
app.use(express.json({ limit: "16kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
const DB = path.join(__dirname, "keys.json");
if (!ADMIN_TOKEN) {
  console.error("Set ADMIN_TOKEN to a long random secret before starting.");
  process.exit(1);
}
function readKeys() {
  try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return []; }
}
function writeKeys(keys) { fs.writeFileSync(DB, JSON.stringify(keys, null, 2), { mode: 0o600 }); }
function admin(req, res, next) {
  const token = req.get("x-admin-token");
  if (!token || token !== ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });
  next();
}
app.post("/api/validate", (req, res) => {
  const key = String(req.body?.key || "").trim();
  if (!key || key.length > 200) return res.status(400).json({ valid: false, message: "Key không hợp lệ." });
  const item = readKeys().find(k => k.key === key);
  const now = Date.now();
  if (!item || !item.active || (item.expiresAt && now > item.expiresAt)) {
    return res.status(401).json({ valid: false, message: "Key sai, đã khóa hoặc hết hạn." });
  }
  item.lastUsedAt = now;
  writeKeys(readKeys().map(k => k.key === key ? item : k));
  res.json({ valid: true, message: "Key hợp lệ." });
});
app.get("/api/admin/keys", admin, (_req, res) => {
  res.json(readKeys().map(({ key, ...rest }) => ({ ...rest, key: key.slice(0, 4) + "••••" })));
});
app.post("/api/admin/keys", admin, (req, res) => {
  const days = Number(req.body?.days || 30);
  if (!Number.isInteger(days) || days < 1 || days > 3650) return res.status(400).json({ error: "days must be 1..3650" });
  const keys = readKeys();
  const key = "LAG-" + crypto.randomBytes(18).toString("hex").toUpperCase();
  const item = { id: crypto.randomUUID(), key, active: true, createdAt: Date.now(), expiresAt: Date.now() + days * 86400000, lastUsedAt: null };
  keys.push(item); writeKeys(keys);
  res.status(201).json(item);
});
app.patch("/api/admin/keys/:id", admin, (req, res) => {
  const keys = readKeys();
  const item = keys.find(k => k.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Not found" });
  if (typeof req.body?.active !== "boolean") return res.status(400).json({ error: "active must be boolean" });
  item.active = req.body.active; writeKeys(keys); res.json({ id: item.id, active: item.active });
});
app.get("/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`LagFix key server listening on ${PORT}`));
