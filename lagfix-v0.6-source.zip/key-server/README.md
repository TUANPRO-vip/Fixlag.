# LagFix key server

## Chạy thử
1. Cài Node.js 20+.
2. Trong thư mục `key-server`, chạy `npm install`.
3. Đặt một admin token dài, ngẫu nhiên:
   - Linux/macOS: `export ADMIN_TOKEN='chuoi-bi-mat-dai-ngau-nhien'`
   - Windows PowerShell: `$env:ADMIN_TOKEN='chuoi-bi-mat-dai-ngau-nhien'`
4. Chạy `npm start`, sau đó mở `http://localhost:3000`.

## Đưa lên mạng
Triển khai thư mục này lên dịch vụ Node.js có HTTPS và lưu trữ bền vững. Đặt biến môi trường `ADMIN_TOKEN`. Không dùng HTTP thường để gửi key/token. Sao lưu `keys.json`; khóa admin không đưa vào APK. Trang quản trị demo nên bổ sung đăng nhập thật, giới hạn tốc độ, nhật ký và bảo vệ CSRF trước khi dùng công khai.

## Kết nối APK
Sửa `apiBase` trong `app/src/main/java/com/lagfix/optimizer/MainActivity.kt` thành URL HTTPS máy chủ, ví dụ `https://keys.example.com`, rồi build APK lại. API:
- `POST /api/validate` với JSON `{"key":"..."}`.
- `GET /api/admin/keys` với header `x-admin-token`.
- `POST /api/admin/keys` với header `x-admin-token` và JSON `{"days":30}`.
- `PATCH /api/admin/keys/:id` với JSON `{"active":false}` để khóa key.

Lưu ý: đây là bản khung minh họa. Bản APK chỉ xác thực khi có mạng; không lưu trạng thái đăng nhập lâu dài để tránh dùng key đã bị thu hồi. Với sản phẩm công khai nên dùng HTTPS, rate limit, database thật và xác thực thiết bị/phân quyền phù hợp.
